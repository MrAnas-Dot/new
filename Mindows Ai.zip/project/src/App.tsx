import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, Code, Download, Wand2 } from 'lucide-react';
import FileUpload from './components/FileUpload';
import CodePreview from './components/CodePreview';
import Header from './components/Header';
import { generateCodeFromTemplate } from './utils/codeGenerator';

export default function App() {
  const [template, setTemplate] = useState<string | null>(null);
  const [generatedCode, setGeneratedCode] = useState({
    html: '',
    css: '',
    javascript: ''
  });

  const handleTemplateUpload = async (files: File[]) => {
    if (files.length === 0) return;

    const file = files[0];
    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file');
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      if (e.target?.result) {
        setTemplate(e.target.result as string);
        const code = await generateCodeFromTemplate(e.target.result as string);
        setGeneratedCode(code);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDownload = () => {
    const files = [
      { name: 'index.html', content: generatedCode.html },
      { name: 'styles.css', content: generatedCode.css },
      { name: 'script.js', content: generatedCode.javascript }
    ];

    files.forEach(file => {
      const blob = new Blob([file.content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white"
    >
      <Header />
      
      <main className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <motion.div 
            className="text-center mb-12"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 text-transparent bg-clip-text">
              Mindows AI Portfolio Generator
            </h1>
            <p className="text-gray-400 text-lg">
              Upload a template image and let AI generate the code for you
            </p>
          </motion.div>

          <div className="grid gap-8">
            <motion.div 
              className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-6 border border-gray-700"
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <div className="flex items-center gap-2 mb-4">
                <Upload className="text-blue-400" />
                <h2 className="text-xl font-semibold">Upload Template Image</h2>
              </div>
              <FileUpload onUpload={handleTemplateUpload} />
              <AnimatePresence>
                {template && (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="mt-4"
                  >
                    <p className="text-sm text-gray-400 mb-2">Template Preview:</p>
                    <motion.img 
                      src={template} 
                      alt="Template" 
                      className="max-h-48 rounded-lg mx-auto"
                      layoutId="template-image"
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>

            <AnimatePresence>
              {generatedCode.html && (
                <motion.div
                  initial={{ y: 50, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: 50, opacity: 0 }}
                  className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-6 border border-gray-700"
                >
                  <div className="flex items-center gap-2 mb-4">
                    <Code className="text-blue-400" />
                    <h2 className="text-xl font-semibold">Generated Code</h2>
                  </div>
                  <CodePreview code={generatedCode} />
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <motion.div 
            className="flex justify-center gap-4 mt-8"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.6 }}
          >
            <motion.button 
              onClick={() => template && generateCodeFromTemplate(template)}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all transform hover:scale-105"
              disabled={!template}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Wand2 size={20} />
              Generate New Version
            </motion.button>
            <motion.button 
              onClick={handleDownload}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all transform hover:scale-105"
              disabled={!generatedCode.html}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Download size={20} />
              Download Code
            </motion.button>
          </motion.div>
        </motion.div>
      </main>
    </motion.div>
  );
}