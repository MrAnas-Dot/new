import { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload } from 'lucide-react';
import { motion } from 'framer-motion';

interface FileUploadProps {
  onUpload: (files: File[]) => void;
}

export default function FileUpload({ onUpload }: FileUploadProps) {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    onUpload(acceptedFiles);
  }, [onUpload]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.gif', '.webp']
    },
    maxFiles: 1
  });

  return (
    <motion.div
      {...getRootProps()}
      className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-all
        ${isDragActive ? 'border-blue-400 bg-blue-400/10' : 'border-gray-600 hover:border-gray-500'}`}
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.99 }}
      animate={isDragActive ? { scale: 1.02 } : { scale: 1 }}
    >
      <input {...getInputProps()} />
      <motion.div
        animate={isDragActive ? { y: [0, -10, 0] } : {}}
        transition={{ repeat: isDragActive ? Infinity : 0, duration: 1 }}
      >
        <Upload className="mx-auto mb-4 text-gray-400" size={32} />
      </motion.div>
      {isDragActive ? (
        <motion.p 
          className="text-blue-400"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          Drop the template here...
        </motion.p>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <p className="mb-2">Drag & drop your template image here</p>
          <p className="text-sm text-gray-400">
            Supports PNG, JPG, JPEG, GIF, and WebP
          </p>
        </motion.div>
      )}
    </motion.div>
  );
}