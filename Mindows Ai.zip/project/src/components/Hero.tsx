import { motion } from 'framer-motion';
import { Github, Linkedin, Mail, ChevronDown } from 'lucide-react';

export default function Hero() {
  return (
    <section className="h-screen flex flex-col justify-center items-center relative bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white">
      <div className="flex flex-col md:flex-row items-center justify-center gap-12 px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="relative group"
        >
          {/* Main photo container with enhanced styling */}
          <div className="relative w-48 h-48 md:w-64 md:h-64">
            {/* Decorative background elements */}
            <div className="absolute inset-0 bg-blue-500 rounded-full opacity-20 blur-xl group-hover:opacity-30 transition-opacity"></div>
            
            {/* Photo frame */}
            <div className="relative w-full h-full rounded-full overflow-hidden ring-4 ring-blue-500 ring-opacity-50 shadow-2xl">
              <img 
                src="/profile.jpg"
                alt="Mohamed Anas"
                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
              />
              
              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-blue-900/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
            </div>

            {/* Animated border */}
            <motion.div 
              className="absolute inset-0 rounded-full border-4 border-blue-400/30"
              animate={{ rotate: 360 }}
              transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
            />
            
            {/* Secondary animated border */}
            <motion.div 
              className="absolute inset-0 rounded-full border-4 border-blue-500/20"
              animate={{ rotate: -360 }}
              transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
            />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center md:text-left"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white to-blue-400">
            Mohamed Anas
          </h1>
          <h2 className="text-xl md:text-2xl text-gray-300 mb-8">Full Stack Developer</h2>
          
          <motion.div 
            className="flex gap-6 mb-12 justify-center md:justify-start"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <a href="https://github.com/MrAnas-Dot" 
               className="hover:text-blue-400 transition-colors transform hover:scale-110"
               target="_blank"
               rel="noopener noreferrer">
              <Github size={24} />
            </a>
            <a href="https://www.linkedin.com/in/mohamed-anas-943594199?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=ios_app" 
               className="hover:text-blue-400 transition-colors transform hover:scale-110"
               target="_blank"
               rel="noopener noreferrer">
              <Linkedin size={24} />
            </a>
            <a href="mailto:smohamedanas99@gmail.com" 
               className="hover:text-blue-400 transition-colors transform hover:scale-110">
              <Mail size={24} />
            </a>
          </motion.div>
        </motion.div>
      </div>

      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="absolute bottom-8 cursor-pointer"
        onClick={() => document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' })}
      >
        <ChevronDown size={32} className="text-gray-400 hover:text-white transition-colors" />
      </motion.div>
    </section>
  );
}