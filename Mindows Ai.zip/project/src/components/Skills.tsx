import { motion } from 'framer-motion';
import { Code2, Database, Globe, Palette, Server, Settings } from 'lucide-react';

const skills = [
  {
    category: "Frontend Development",
    icon: <Globe className="w-6 h-6" />,
    items: ["HTML", "CSS", "JavaScript", "React"]
  },
  {
    category: "Backend Development",
    icon: <Server className="w-6 h-6" />,
    items: ["Python", "Django"]
  },
  {
    category: "Database",
    icon: <Database className="w-6 h-6" />,
    items: ["MySql", "MongoDB","Git","GitHub"]
  },
  {
    category: "DevOps",
    icon: <Settings className="w-6 h-6" />,
    items: ["Docker", "Kubernetes", "AWS", "CI/CD"]
  },
  {
    category: "UI/UX Design",
    icon: <Palette className="w-6 h-6" />,
    items: ["Figma"]
  },
  {
    category: "Programming Languages",
    icon: <Code2 className="w-6 h-6" />,
    items: ["JavaScript", "Python"]
  }
];

export default function Skills() {
  return (
    <section className="py-20 bg-gray-800 text-white" id="skills">
      <div className="container mx-auto px-4">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl font-bold mb-12 text-center"
        >
          Skills & Expertise
        </motion.h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skills.map((skill, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-gray-700 rounded-lg p-6 hover:bg-gray-600 transition-colors"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-blue-500 bg-opacity-20 rounded-lg text-blue-400">
                  {skill.icon}
                </div>
                <h3 className="text-xl font-semibold">{skill.category}</h3>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {skill.items.map((item, itemIndex) => (
                  <span
                    key={itemIndex}
                    className="px-3 py-1 bg-gray-800 rounded-full text-sm"
                  >
                    {item}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}