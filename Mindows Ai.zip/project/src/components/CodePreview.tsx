import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';

interface CodePreviewProps {
  code: {
    html: string;
    css: string;
    javascript: string;
  };
}

export default function CodePreview({ code }: CodePreviewProps) {
  const [activeTab, setActiveTab] = useState<'html' | 'css' | 'javascript'>('html');

  return (
    <div>
      <div className="flex gap-2 mb-4">
        {(['html', 'css', 'javascript'] as const).map((tab, index) => (
          <motion.button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-lg capitalize ${
              activeTab === tab
                ? 'bg-blue-500 text-white'
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {tab}
          </motion.button>
        ))}
      </div>

      <motion.div 
        className="bg-gray-900 rounded-lg overflow-hidden"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
          >
            <SyntaxHighlighter
              language={activeTab}
              style={vscDarkPlus}
              customStyle={{
                margin: 0,
                padding: '1rem',
                borderRadius: '0.5rem',
                background: 'transparent'
              }}
            >
              {code[activeTab]}
            </SyntaxHighlighter>
          </motion.div>
        </AnimatePresence>
      </motion.div>
    </div>
  );
}